export const API_URL = "http://localhost:3000"

// export const API_URL = "https://quick-backend-nodejs.onrender.com"